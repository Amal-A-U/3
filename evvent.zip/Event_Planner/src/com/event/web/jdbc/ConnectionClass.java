package com.event.web.jdbc;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class ConnectionClass  {
	private static Connection conn;
	
	
	 public static Connection getConnection() {
	        try {
	          
	            Class.forName("oracle.jdbc.driver.OracleDriver");
	           
	            try {
	            	 conn = DriverManager.getConnection("jdbc:oracle:thin:@sla18326:1521:ukahp1d","AZT_TRN","Azt_trn1#");
	            	// System.out.println("driver manager."); 
	            }
	            catch (SQLException ex) {
	                // log an exception. for example:
	                System.out.println("Failed to create the database connection."); 
	            }
	        } 
	        catch (ClassNotFoundException ex) {
	            // log an exception. for example:
	            System.out.println("Driver not found."); 
	        }
	        return conn;
	    }
}



   


