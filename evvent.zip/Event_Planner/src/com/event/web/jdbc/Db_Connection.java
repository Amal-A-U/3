package com.event.web.jdbc;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.annotation.Resource;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.sql.DataSource;

/**
 * Servlet implementation class Db_Connection
 */
@WebServlet("/Db_Connection")
public class Db_Connection extends HttpServlet {
	private static final long serialVersionUID = 1L;
    //Define DataSource/Connection pool for resource injection
	@Resource(name="eventDB")
	private DataSource dataSource;
  

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	
		//1.set up the printwriter
		PrintWriter out=response.getWriter();
		response.setContentType("text/plain");
		
		//2.get a connection to the database
		Connection conn=null;
		Statement stmt=null;
		ResultSet rs=null;
		
		try{
			conn=dataSource.getConnection();
		
			
			//3.create a sql statements
			String sql="select * from AMAL_EMPLOYEE";
			stmt=conn.createStatement();
			//4.execute sql query
			rs=stmt.executeQuery(sql);
			//5.process the resultset
			while(rs.next()){
				String email=rs.getString("email");
				out.println(email);
			}
		}
		catch(Exception exc){
			exc.printStackTrace();
		}
		
		
			
	}
	
	


}
