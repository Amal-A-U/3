package com.event.dao;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.event.bean.Emp_RegBean;
import com.event.web.jdbc.ConnectionClass;

public class Emp_Registerdao {
	Connection con=null;
	java.sql.Statement stmt= null;
	ResultSet rs = null;

	public ResultSet insertEmpDetails(Emp_RegBean objEmp_RegBean) {
		
		con=ConnectionClass.getConnection();
		try {
			stmt=con.createStatement();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		String sql="insert into AMAL_EMPLOYEE (EMPLOYEE_ID,FNAME,LNAME,AGE,GENDER,DEPT_ID,EMAIL,PHONE,PASSWORD,PASSWORD1) values('"+objEmp_RegBean.getEid()+"','"+objEmp_RegBean.getFirstName()+"','"+objEmp_RegBean.getLastName()+"','"+objEmp_RegBean.getAge()+"','"+objEmp_RegBean.getGender()+"','"+objEmp_RegBean.getDept()+"','"+objEmp_RegBean.getEmail()+"','"+objEmp_RegBean.getPhone()+"','"+objEmp_RegBean.getPassword()+"','"+objEmp_RegBean.getPassword1()+"')";
		try {
			rs=stmt.executeQuery(sql);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return rs;
	}
	
	

}
